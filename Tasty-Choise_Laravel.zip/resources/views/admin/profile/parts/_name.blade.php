<td class="d-flex align-items-center">
    <!--begin::User details-->
    <div class="d-flex flex-column">
        <a href="view.html" class="text-gray-800 text-hover-primary mb-1">{{$model->name}}</a>
        <span>{{$model->email}}</span>
    </div>
    <!--begin::User details-->
</td>