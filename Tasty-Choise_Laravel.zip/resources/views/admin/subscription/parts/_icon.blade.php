<img width="80px" height="80px" src="{{ asset('storage/' . $modal->image) }}" alt="subscription Icon">
