<img width="80px" height="80px" src="{{ asset('storage/' . $modal->icon) }}" alt="resturant Icon">
