<img width="80px" height="80px" src="{{ asset('storage/' . $model->image) }}" alt="Ads image">
