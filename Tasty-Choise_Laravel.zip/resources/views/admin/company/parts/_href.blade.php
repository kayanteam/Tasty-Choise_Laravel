<td class="d-flex align-items-center">
    <!--begin::User details-->
    <div class="d-flex flex-column">
        <a href="{{route('services.index' , $modal->id)}}" style="font-weight: bold; !important" class="text-light text-hover-light mb-1 btn btn-primary">{{$modal->services()->count()}} خدمة</a>
    </div>
    <!--begin::User details-->
</td>